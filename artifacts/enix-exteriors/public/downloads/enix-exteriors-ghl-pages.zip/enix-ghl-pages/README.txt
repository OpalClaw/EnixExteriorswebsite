ENIX EXTERIORS — GHL (GoHighLevel) Custom HTML Pages
======================================================
Each numbered HTML file is a fully self-contained page.
Paste the entire contents of each file into a separate
GoHighLevel "Custom HTML" block for the matching menu item.

PAGE → GHL MENU ITEM MAPPING
-----------------------------
01-Home.html                     → Home                       (slug: /)
02-Commercial-Roofing.html       → Commercial Roofing         (slug: /commercial-roofing)
03-Residential-Roofing.html      → Residential Roofing        (slug: /residential-roofing)
04-Exterior-Services.html        → Exterior Services          (slug: /exterior-services)
05-Storm-Damage-Commercial.html  → Storm Damage – Commercial  (slug: /storm-damage-commercial)
06-Storm-Damage-Residential.html → Storm Damage – Residential (slug: /storm-damage-residential)
07-Education-Hub.html            → Education Hub              (slug: /education-hub)
08-About.html                    → About                      (slug: /about)
09-Contact.html                  → Contact                    (slug: /contact)
10-Tennessee-Locations.html      → Tennessee Locations        (slug: /tennessee-locations)

HOW TO PASTE INTO GHL
---------------------
1. In GoHighLevel, go to Sites → Funnels/Websites → your site.
2. Open (or create) the page matching the label above.
3. Add a "Custom HTML" element (or replace the existing one).
4. Open the numbered HTML file, select ALL text (Ctrl+A / Select All),
   then copy and paste into the Custom HTML box in GHL.
5. Save & Publish the page.
6. Repeat for each numbered file.

IMPORTANT NOTES
---------------
- Each file is 100% self-contained: inline CSS, inline SVG icons,
  inline JavaScript — no external dependencies to break in GHL.
- Navigation links use the slugs listed above. Make sure your GHL
  page slugs exactly match (e.g. /commercial-roofing, not /commercial).
- Phone: (865) 685-ENIX  |  Email: INFO@ENIXEXTERIORS.COM
- Address: 5992 Bearden View Ln, Knoxville TN 37909
