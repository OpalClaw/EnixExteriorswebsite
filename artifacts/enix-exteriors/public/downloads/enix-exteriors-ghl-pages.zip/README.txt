ENIX EXTERIORS — GHL CUSTOM HTML PAGES
========================================

This folder contains all 10 standalone HTML pages for your Enix Exteriors
website, ready to paste into GoHighLevel (GHL) Custom HTML blocks.

Each .html file is fully self-contained:
  - All CSS is inline
  - All icons are inline SVG (no external icon library)
  - All JavaScript is inline
  - Images are referenced as "images/<filename>"  (relative path)


------------------------------------------------------------
FILE → GHL MENU ITEM
------------------------------------------------------------

  01-Home.html                       →  Home  (your homepage / "/")
  02-Commercial-Roofing.html         →  Services > Commercial Roofing
  03-Residential-Roofing.html        →  Services > Residential Roofing
  04-Exterior-Services.html          →  Services > Exterior Services
  05-Storm-Damage-Commercial.html    →  Services > Storm Damage Commercial
  06-Storm-Damage-Residential.html   →  Services > Storm Damage Residential
  07-Education-Hub.html              →  Education Hub
  08-About.html                      →  About
  09-Contact.html                    →  Contact
  10-Tennessee-Locations.html        →  Locations


------------------------------------------------------------
RECOMMENDED GHL PAGE URL SLUGS
------------------------------------------------------------

For the cross-page navigation links to keep working in GHL, create each
GHL page with a URL/slug that matches the filename (without the number
prefix) — for example:

  01-Home.html                       →  /                        (home)
  02-Commercial-Roofing.html         →  /commercial-roofing.html
  03-Residential-Roofing.html        →  /residential-roofing.html
  04-Exterior-Services.html          →  /exterior-services.html
  05-Storm-Damage-Commercial.html    →  /storm-damage-commercial.html
  06-Storm-Damage-Residential.html   →  /storm-damage-residential.html
  07-Education-Hub.html              →  /education-hub.html
  08-About.html                      →  /about.html
  09-Contact.html                    →  /contact.html
  10-Tennessee-Locations.html        →  /tennessee-locations.html

(If your GHL slugs don't include ".html", you'll need to find/replace
those references inside each file using a text editor.)


------------------------------------------------------------
HOW TO PASTE INTO GHL (FROM YOUR PHONE)
------------------------------------------------------------

  1. Tap the .html file you want (e.g. 02-Commercial-Roofing.html)
  2. Open it with a text editor app (Files by Google, Acode,
     Quickedit, Markor, etc. — any plain-text viewer works)
  3. Select All → Copy
  4. In GHL, open the matching page > add a Custom HTML block
  5. Paste the entire contents into the Custom HTML editor
  6. Save


------------------------------------------------------------
IMAGES
------------------------------------------------------------

The 16 image files in the /images folder are referenced by every page
(hero backgrounds, service photos, etc.). You have two options:

  A) Upload the entire /images folder to your site root in GHL so the
     paths "images/xxx.jpg" resolve.

  B) Upload each image to GHL's Media Library, then in each .html file
     do a find-and-replace of "images/<filename>" with the full GHL
     media URL it gives you.


------------------------------------------------------------
BRAND DETAILS BAKED INTO EVERY PAGE
------------------------------------------------------------

  Phone:   (865) 685-ENIX     (tel:8656853649)
  Email:   INFO@ENIXEXTERIORS.COM
  Address: 5992 Bearden View Ln, Knoxville TN 37909

If any of these change, update them in EVERY .html file (or edit
build_pages.mjs in the project and regenerate).
